var db=require('../dbconnection');
var fs = require('fs');
var Item=
{ 
Save_Item:function(Item_,callback)
    {
        console.log(Item_)
    return db.query("CALL Save_Item("+"@Item_Id_ :=?,"+"@Group_Id_ :=?,"+"@Group_Name_ :=?,"+
    "@Saleunit_Id_ :=?,"+"@Saleunit_Name_ :=?,"+"@Item_Code_ :=?,"+"@Item_Name_ :=?,"+
    "@Sales_Tax_ :=?,"+"@HSNMasterId_ :=?,"+"@HSNCODE_ :=?,"+"@Country_Id_ :=?,"+
    "@Country_Name_ :=?,"+"@Is_Update_ :=?,"+"@Checkbox_ :=?"+")"
    ,[Item_.Item_Id,Item_.Group_Id,Item_.Group_Name,Item_.Saleunit_Id,Item_.Saleunit_Name,
    Item_.Item_Code,Item_.Item_Name,Item_.Sales_Tax,Item_.HSNMasterId,Item_.HSNCODE, 
    Item_.Country_Id, Item_.Country_Name,Item_.Is_Update, Item_.Checkbox,],callback);
    },
Delete_Item:function(Item_Id_,callback)
    { 
    return db.query("CALL Delete_Item(@Item_Id_ :=?)",[Item_Id_],callback);
    },
Get_Item:function(Item_Id_,callback)
    { 
    return db.query("CALL Get_Item(@Item_Id_ :=?)",[Item_Id_],callback);
    },
HSN_Dropdown:function(callback)
    { 
    return db.query("CALL HSN_Dropdown()",[],callback);
    },

    Search_Item:function(Item_Name_,Group_Id_,Item_Code_,callback)
    { 
    if (Item_Name_==='undefined'||Item_Name_===''||Item_Name_===undefined )
    Item_Name_='';
    if (Item_Code_==='undefined'||Item_Code_===''||Item_Code_===undefined )
        Item_Code_='';

    
    console.log('ItemName2_: ', Item_Name_);
    console.log('ItemCode2_: ', Item_Code_);

    const specialCharacters = /([~@#$%^&*()_+\-=[\]\\{}|;:'",.<>?/])/g;

		if (specialCharacters.test(Item_Name_)) {
			console.log("String contains special characters.");
            Item_Name_ = Item_Name_.replace(/\\/g, '\\\\');
			// Item_Name_ = Item_Name_.replace(specialCharacters, '\\$&');
		} else {
			console.log("String does not contain special characters.");
		}
	
		console.log('Escaped Item_Name_:', Item_Name_);

        const specialCharacters1 = /([~@#$%^&*()_+\-=[\]\\{}|;:'",.<>?/])/g;


        if (specialCharacters1.test(Item_Code_)) {
            console.log("Item_Code_ contains special characters.");
            Item_Code_ = Item_Code_.replace(/\\/g, '\\\\'); // Escape backslashes
            console.log('Item_Code_: ', Item_Code_);
        } else {
            console.log("Item_Code_ does not contain special characters.");
        }
    
        console.log('Escaped Item_Code_: ', Item_Code_);
    
     return db.query("CALL Search_Item("+"@Item_Name_ :=?,"+"@Group_Id_ :=?,"+"@Item_Code_ :=?"+")",[Item_Name_,Group_Id_,Item_Code_],callback);
    },
    // Is_Date_Check_,From_Date_,To_Date_,Customer_,QuotNo_,partNo_,Item_Group_Id_,CurrencyDetails_Id_,User_Details_Id_,Account_Type_Id_

Item_Typeahead:function(Item_Name_,callback)
    { 
    if (Item_Name_ === undefined || Item_Name_ === "undefined" )
    Item_Name_='';
    return db.query("CALL Item_Typeahead(@Item_Name_ :=?)",[Item_Name_],callback);
    },

     
Save_Service_Type:function(Service_Type_,callback)
{
    console.log(Service_Type_)
    return db.query("CALL Save_Service_Type("+"@Service_Type_Id_ :=?,"+"@Service_Type_Name_ :=?,"+
        "@Hsn_Id_ :=?," + "@Hsn_Name_ :=?," + "@CGST_ :=?," + "@SGST_ :=?," + "@IGST_ :=?," +"@GST_ :=?"+")"
        , [Service_Type_.Service_Type_Id, Service_Type_.Service_Type_Name, Service_Type_.Hsn_Id, Service_Type_.Hsn_Name,
            Service_Type_.CGST,Service_Type_.SGST, Service_Type_.IGST,Service_Type_.GST],callback);
    },
Delete_Service_Type:function(Service_Type_Id_,callback)
    { 
    return db.query("CALL Delete_Service_Type(@Service_Type_Id_ :=?)",[Service_Type_Id_],callback);
    },
Get_Service_Type:function(Service_Type_Id_,callback)
    { 
    return db.query("CALL Get_Service_Type(@Service_Type_Id_ :=?)",[Service_Type_Id_],callback);
    },
Search_Service_Type:function(Service_Type_Name_,callback)
    { 
    if (Service_Type_Name_==='undefined'||Service_Type_Name_===''||Service_Type_Name_===undefined )
    Service_Type_Name_='';
     return db.query("CALL Search_Service_Type(@Service_Type_Name_ :=?)",[Service_Type_Name_],callback);
    },
};
module.exports=Item;

